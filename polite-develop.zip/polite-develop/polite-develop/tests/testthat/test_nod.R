context("Nod")
library(polite)


