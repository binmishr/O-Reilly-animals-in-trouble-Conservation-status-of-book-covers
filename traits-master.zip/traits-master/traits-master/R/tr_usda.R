#' USDA plants data
#' 
#' DEFUNCT
#'
#' @export
#' @param ... ignored
#' @rdname tr_usda-defunct
#' @keywords internal
tr_usda <- function(...) {
  .Defunct(msg = "the plantsdb.xyz API is down for good")
}
