#' Search for traits from EOL's Traitbank
#'
#' 
#'
#' # traitbank function
#' res <- traitbank(query = "MATCH (n:Trait) RETURN n LIMIT 2;")
#' res
#' }
traitbank <- function(query, key = NULL, ...) {
  assert(query, "character")
  assert(key, "character")
  if (is.null(key)) key <- Sys.getenv("EOL_CYPHER_KEY", "")
  if (!nzchar(key)) stop("no EOL Cypher key found; see help file")
  x = crul::HttpClient$new(
      url = "https://eol.org",
      headers = list(Authorization = paste0("JWT ", key)),
      opts = list(...)
  )
  res <- x$get("service/cypher", query = list(query = query))
  res$raise_for_status()
  jsonlite::fromJSON(res$parse("UTF-8"), TRUE)
}
